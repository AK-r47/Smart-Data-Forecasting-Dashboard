from flask import Flask, request, render_template, redirect, url_for, session
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
import os
from sklearn.metrics import mean_squared_error
import numpy as np
from datetime import datetime
import json

app = Flask(__name__)
app.secret_key = 'your-secret-key-here-change-in-production'
UPLOAD_FOLDER = 'uploads'

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Mock user database (replace with real database in production)
USERS = {
    'kumbharaman555@gmail.com': 'Aman123',
    'demo@example.com': 'demo123',
    'user@example.com': 'password123'
}

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if email in USERS and USERS[email] == password:
            session['user'] = email
            session['logged_in'] = True
            return redirect(url_for('dashboard'))
        else:
            return render_template('login.html', error='Invalid email or password')
    
    if session.get('logged_in'):
        return redirect(url_for('dashboard'))
    
    return render_template('login.html')

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    
    forecast = None
    rmse = None
    columns = []
    preview = None
    filename = None
    chart_data = None
    theme = request.args.get('theme', 'dark')

    if request.method == 'POST':
        # File upload and loading
        if 'file' in request.files and request.files['file'].filename != '':
            file = request.files['file']
            filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(filename)
            df = pd.read_csv(filename)
            columns = list(df.columns)
            preview = df.head(10).to_html(classes='data-table')
        else:
            filename = request.form.get('filename')
            if filename:
                df = pd.read_csv(filename)
                columns = list(df.columns)
                preview = df.head(10).to_html(classes='data-table')

        selected_column = request.form.get('column')
        order_raw = request.form.get('order')
        steps = int(request.form.get('steps', '12'))

        if selected_column and order_raw and filename:
            try:
                series = pd.read_csv(filename)[selected_column]
                series = pd.to_numeric(series, errors='coerce').dropna()

                order = tuple(int(x) for x in order_raw.split(','))
                train_size = int(len(series) * 0.8)
                train, test = series[:train_size], series[train_size:]
                
                model = ARIMA(train, order=order)
                fit = model.fit()
                preds = fit.predict(start=train_size, end=len(series)-1)
                forecast_values = fit.forecast(steps=steps).tolist()
                rmse = np.sqrt(mean_squared_error(test, preds))
                
                # Create chart data
                forecast = [round(float(v), 2) for v in forecast_values]
                chart_data = json.dumps({
                    'steps': list(range(1, steps + 1)),
                    'values': forecast,
                    'rmse': round(float(rmse), 4)
                })
                
            except Exception as e:
                forecast = f"Error: {str(e)}"

    return render_template(
        'dashboard.html',
        forecast=forecast,
        rmse=rmse,
        columns=columns,
        preview=preview,
        filename=filename,
        chart_data=chart_data,
        theme=theme,
        user=session.get('user')
    )

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)